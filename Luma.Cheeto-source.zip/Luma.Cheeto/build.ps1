param([string]$Config = "Release", [string]$Platform = "x64")
$ErrorActionPreference = "Stop"
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (!(Test-Path $vswhere)) { throw "Visual Studio 2022 with C++ workload is required." }
$msbuild = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe | Select-Object -First 1
if (!$msbuild) { throw "MSBuild was not found. Install the VS 2022 Desktop development with C++ workload." }
& $msbuild "Luma.Cheeto.sln" /p:Configuration=$Config /p:Platform=$Platform /m /v:minimal
if ($LASTEXITCODE -ne 0) { throw "Build failed with exit code $LASTEXITCODE" }
if (!(Test-Path "dist\Luma.Cheeto.exe")) { throw "Build completed but expected output was not found." }
Write-Host "Built: dist\Luma.Cheeto.exe"
