# Luma.Cheeto 2.0.0 — Diagnostics Build

This is a buildable Windows x64 C++20 diagnostic shell using native Win32 controls. It detects FiveM process names and reports the highest matching build number. It does **not** open FiveM with `OpenProcess`, read/write game memory, extract player/entity data, manipulate aim, inject code, or attempt anti-cheat evasion.

## Requirements
- Windows 10/11 x64
- Visual Studio 2022 with **Desktop development with C++**
- MSVC v143 and Windows 10/11 SDK

## Build
Open `Luma.Cheeto.sln`, choose **Release | x64**, then Build Solution. Or run in PowerShell from this directory:

```powershell
.\build.ps1
```

Expected output: `dist\Luma.Cheeto.exe`.

## Runtime
Double-click `dist\Luma.Cheeto.exe`. The app checks for process names matching `FiveM_b<digits>_GTAProcess.exe` every five seconds. Diagnostics logs are written to `%APPDATA%\Luma.Cheeto\diagnostics.log`. It does not need administrator privileges or third-party DLLs.

## Package status
The source and solution are provided. A Windows `.exe` is not included in this source package because this build environment does not have MSVC/MSBuild; build it on Windows with the supplied solution or `build.ps1`. No placeholder executable is shipped.

## Scope
The UI is a foundation for a standalone diagnostics app, not a functional game ESP/aiming tool. Live memory extraction, aim manipulation, and anti-cheat evasion are not implemented.

## Build remotely without installing Visual Studio locally

The `.github/workflows/build-windows.yml` workflow uses a hosted Windows runner. Upload this project to a GitHub repository, open **Actions**, select **Build Luma.Cheeto (Windows x64)**, and click **Run workflow**. When it finishes, download the `Luma.Cheeto-win-x64` artifact from that run. This requires a GitHub account and uploading the source project. The workflow builds only the diagnostics application described above.
