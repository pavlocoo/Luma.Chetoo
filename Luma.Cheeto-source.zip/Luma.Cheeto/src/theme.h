#pragma once
// Luma palette: Win32 COLORREF uses 0x00BBGGRR.
#define LUMA_BG_RGB RGB(22, 5, 35)
#define LUMA_PANEL_RGB RGB(38, 10, 58)
#define LUMA_MAGENTA_RGB RGB(255, 0, 255)
#define LUMA_PURPLE_RGB RGB(176, 38, 255)
