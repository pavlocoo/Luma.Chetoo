#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <tlhelp32.h>
#include <string>
#include <vector>
#include <algorithm>
#include <regex>
#include <filesystem>
#include <fstream>
#include <sstream>
#include "app.h"

static HWND g_status = nullptr;
static HWND g_details = nullptr;
static HFONT g_font = nullptr;
static const COLORREF BG = RGB(22, 5, 35);
static const COLORREF PANEL = RGB(38, 10, 58);
static const COLORREF MAGENTA = RGB(255, 0, 255);
static const COLORREF TEXT = RGB(245, 225, 255);

std::wstring DetectFiveM() {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return L"No FiveM process detected";
    PROCESSENTRY32W pe{}; pe.dwSize = sizeof(pe);
    std::vector<std::pair<unsigned long, std::wstring>> found;
    const std::wregex pattern(LR"(^FiveM_b([0-9]+)_GTAProcess\.exe$)", std::regex_constants::icase);
    if (Process32FirstW(snap, &pe)) {
        do {
            std::wsmatch match;
            std::wstring name(pe.szExeFile);
            if (std::regex_match(name, match, pattern)) {
                try { found.emplace_back(std::stoul(match[1].str()), name); } catch (...) {}
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    if (found.empty()) return L"No supported FiveM process detected";
    auto best = *std::max_element(found.begin(), found.end(),
        [](const auto& a, const auto& b) { return a.first < b.first; });
    std::wstringstream ss;
    ss << L"Detected process: " << best.second << L"\r\n"
       << L"Process-name build: " << best.first << L"\r\n"
       << L"Mode: diagnostics only; no game memory access.";
    return ss.str();
}

static void RefreshStatus() {
    const auto text = DetectFiveM();
    SetWindowTextW(g_details, text.c_str());
    SetWindowTextW(g_status, text.find(L"Detected process:") == 0 ? L"FiveM process found" : L"Waiting for FiveM");
    std::wofstream log(GetLogPath(), std::ios::app);
    if (log) log << L"[refresh] " << text << L"\r\n";
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE: {
        g_font = CreateFontW(-18, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
            OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        CreateWindowW(L"STATIC", L"LUMA.CHEETO", WS_CHILD | WS_VISIBLE, 22, 18, 300, 34, hwnd, nullptr, nullptr, nullptr);
        g_status = CreateWindowW(L"STATIC", L"Starting diagnostics…", WS_CHILD | WS_VISIBLE, 22, 64, 370, 26, hwnd, nullptr, nullptr, nullptr);
        g_details = CreateWindowW(L"STATIC", L"", WS_CHILD | WS_VISIBLE, 22, 105, 380, 112, hwnd, nullptr, nullptr, nullptr);
        CreateWindowW(L"BUTTON", L"Refresh", WS_CHILD | WS_VISIBLE | BS_OWNERDRAW, 22, 236, 100, 34, hwnd, (HMENU)1001, nullptr, nullptr);
        CreateWindowW(L"STATIC", L"Diagnostics build 2.0.0  •  Read-only process-name detection", WS_CHILD | WS_VISIBLE,
            22, 292, 390, 24, hwnd, nullptr, nullptr, nullptr);
        EnumChildWindows(hwnd, [](HWND child, LPARAM) -> BOOL {
            SendMessageW(child, WM_SETFONT, (WPARAM)g_font, TRUE); return TRUE;
        }, 0);
        RefreshStatus();
        SetTimer(hwnd, 1, 5000, nullptr);
        return 0;
    }
    case WM_TIMER: RefreshStatus(); return 0;
    case WM_COMMAND:
        if (LOWORD(wp) == 1001) RefreshStatus();
        return 0;
    case WM_DRAWITEM: {
        auto* dis = reinterpret_cast<DRAWITEMSTRUCT*>(lp);
        HBRUSH brush = CreateSolidBrush(RGB(72, 18, 104));
        FillRect(dis->hDC, &dis->rcItem, brush); DeleteObject(brush);
        SetBkMode(dis->hDC, TRANSPARENT); SetTextColor(dis->hDC, TEXT);
        DrawTextW(dis->hDC, L"Refresh", -1, &dis->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        return TRUE;
    }
    case WM_CTLCOLORSTATIC: {
        HDC dc = (HDC)wp;
        SetTextColor(dc, TEXT); SetBkColor(dc, BG);
        static HBRUSH bg = CreateSolidBrush(BG);
        return (LRESULT)bg;
    }
    case WM_ERASEBKGND: {
        RECT r; GetClientRect(hwnd, &r);
        HBRUSH b = CreateSolidBrush(BG); FillRect((HDC)wp, &r, b); DeleteObject(b);
        return 1;
    }
    case WM_DESTROY:
        KillTimer(hwnd, 1);
        if (g_font) DeleteObject(g_font);
        PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    AppEnsurePaths();
    WNDCLASSW wc{}; wc.lpfnWndProc = WndProc; wc.hInstance = instance;
    wc.lpszClassName = L"LumaCheetoDiagnostics"; wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = CreateSolidBrush(BG);
    wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
    if (!RegisterClassW(&wc)) return 1;
    HWND hwnd = CreateWindowExW(WS_EX_TOPMOST, wc.lpszClassName, L"Luma.Cheeto — Diagnostics",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX, CW_USEDEFAULT, CW_USEDEFAULT,
        450, 370, nullptr, nullptr, instance, nullptr);
    if (!hwnd) return 2;
    ShowWindow(hwnd, show); UpdateWindow(hwnd);
    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    return (int)msg.wParam;
}
