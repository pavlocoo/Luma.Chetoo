#pragma once
#include <windows.h>
#include <string>
#include <filesystem>
void AppEnsurePaths();
std::filesystem::path GetLogPath();
