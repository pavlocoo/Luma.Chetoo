#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlobj.h>
#include <filesystem>
#include "app.h"

static std::filesystem::path AppDir() {
    PWSTR raw = nullptr;
    std::filesystem::path p;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_RoamingAppData, 0, nullptr, &raw)) && raw) {
        p = raw; CoTaskMemFree(raw);
    } else {
        p = std::filesystem::temp_directory_path();
    }
    return p / L"Luma.Cheeto";
}
void AppEnsurePaths() {
    std::error_code ec;
    std::filesystem::create_directories(AppDir(), ec);
}
std::filesystem::path GetLogPath() { return AppDir() / L"diagnostics.log"; }
